from typing import Optional, Tuple, Union

OptionalImageSize = Union[int, Tuple[Optional[int], Optional[int]]]
