"""Package with tools to work with the DocILE dataset and benchmark."""
